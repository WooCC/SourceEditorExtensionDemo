//
//  SourceEditorCommand.swift
//  JSonToMapModelTool
//
//  Created by 吴承炽 on 2019/1/11.
//  Copyright © 2019年 Wcc. All rights reserved.
//

import Foundation
import XcodeKit

class SourceEditorCommand: NSObject, XCSourceEditorCommand {
    var classContent = [Array<String>]()
    func perform(with invocation: XCSourceEditorCommandInvocation, completionHandler: @escaping (Error?) -> Void ) -> Void {
        
        
        print("看看这是啥：\(invocation.buffer.lines)")
        print("再看看这个：\(invocation.buffer.completeBuffer)")
        do {
            var jsonStr = invocation.buffer.completeBuffer
            if invocation.buffer.completeBuffer.contains("=") {
                jsonStr.replacingOccurrences(of: "=", with: ":")
            }
            if invocation.buffer.completeBuffer.contains(";") {
                jsonStr.replacingOccurrences(of: ";", with: ",")
            }
            print("新的：\(jsonStr)")
        
            let data = jsonStr.data(using: .utf8)!
            let dic:[String: AnyObject] = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! [String: AnyObject]
            
            self.interateJson(jsonObj: dic as AnyObject, className: "ClassName")
            for arr in classContent.reversed() {
                invocation.buffer.lines.addObjects(from: arr)
            }
        } catch {
            //            print(error.localizedDescription)
            completionHandler(error)
        }
        
        
        completionHandler(nil)
    }
    
    func interateJson(jsonObj: AnyObject, className: String) -> Void {
        var content = [String]()
        if jsonObj.isKind(of: NSDictionary.self) {
            let dic = jsonObj as! [String: AnyObject]
            for (key, value) in dic {
                if value.isKind(of: NSString.self) {
                    content.append("    var \(key): \tString?")
                } else if value.isKind(of: NSArray.self) {
                    content.append("    var \(key): [<#\(key)OfClass#>]?")
                    let arr = value as! Array<AnyObject>
                    if arr.count > 0 {
                        if arr.first!.isKind(of: NSDictionary.self) {
                            interateJson(jsonObj: arr.first as AnyObject, className: "\(key)OfClass")
                        }
                    }
                    
                } else if value.isKind(of: NSDictionary.self) {
                    content.append("    var \(key): \t<#\(key)OfClass#>?")
                    
                    interateJson(jsonObj: value, className: "\(key)OfClass")
                    
                } else if value.isKind(of: NSNumber.self) {
                    content.append("    var \(key): \tDouble = 0.0")
                }
            }
        }
        
        content.insert("\nclass <#\(className)#> : BaseJsonModel {\n\n", at: 0)
        content.insert("import Alamofire\n", at: 0)
        content.insert("import ObjectMapper\n", at: 0)

        content.append("\n    override func mapping(map: Map) {")
        
        if jsonObj.isKind(of: NSDictionary.self) {
            let dic = jsonObj as! [String: AnyObject]
            for (key, value) in dic {
                content.append("        \(key)            <- map[\"\(key)\"]")
            }
        }
        content.append("    }")
        content.append("}")
        classContent.append(content)
    }
    
}
