//
//  ViewController.swift
//  SourceEditorExtensionDemo
//
//  Created by 吴承炽 on 2019/1/11.
//  Copyright © 2019年 Wcc. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}

