//
//  AppDelegate.swift
//  SourceEditorExtensionDemo
//
//  Created by 吴承炽 on 2019/1/11.
//  Copyright © 2019年 Wcc. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

