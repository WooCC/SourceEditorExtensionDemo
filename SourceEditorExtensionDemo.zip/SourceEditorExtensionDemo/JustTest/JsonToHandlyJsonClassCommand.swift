//
//  JsonToMapClassCommand.swift
//  JustTest
//
//  Created by 吴承炽 on 2019/1/11.
//  Copyright © 2019年 Wcc. All rights reserved.
//

import Foundation
import XcodeKit

class JsonToHandlyJsonClassCommand: NSObject, XCSourceEditorCommand {
    var classContent = [Array<String>]()
    
    func perform(with invocation: XCSourceEditorCommandInvocation, completionHandler: @escaping (Error?) -> Void ) -> Void {
        print(invocation.buffer.lines)
        print(invocation.buffer.completeBuffer)
        do {
            let data = invocation.buffer.completeBuffer.data(using: .utf8)!
            let dic:[String: AnyObject] = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! [String: AnyObject]
            
            self.interateJson(jsonObj: dic as AnyObject, className: "ClassName")
            for arr in classContent.reversed() {
                invocation.buffer.lines.addObjects(from: arr)
            }
        } catch {
            //            print(error.localizedDescription)
            completionHandler(error)
        }
        
        completionHandler(nil)
    }
    
    func interateJson(jsonObj: AnyObject, className: String) -> Void {
        var content = [String]()
        if jsonObj.isKind(of: NSDictionary.self) {
            let dic = jsonObj as! [String: AnyObject]
            for (key, value) in dic {
                if value.isKind(of: NSString.self) {
//                    content.append("@property (nonatomic, copy) \tNSString *\(key);")
                    content.append("var \(key): \tString?")
                } else if value.isKind(of: NSArray.self) {
//                    content.append("@property (nonatomic, strong) \tNSArray<<#\(key)OfClass#>> *\(key);")
                    content.append("var \(key): [<#\(key)OfClass#>]?")
                    let arr = value as! Array<AnyObject>
                    if arr.count > 0 {
                        if arr.first!.isKind(of: NSDictionary.self) {
                            interateJson(jsonObj: arr.first as AnyObject, className: "\(key)OfClass")
                        }
                    }
                    
                } else if value.isKind(of: NSDictionary.self) {
//                    content.append("@property (nonatomic, strong) \t<#\(key)OfClass#> *\(key);")
                    content.append("var \(key): \t<#\(key)OfClass#>?")
                    
                    interateJson(jsonObj: value, className: "\(key)OfClass")
                    
                } else if value.isKind(of: NSNumber.self) {
//                    content.append("@property (nonatomic, copy) \tNSNumber *\(key);")
                    content.append("var \(key): \tNSNumber?")
                }
            }
        }
        
        content.insert("\n\nclass <#\(className)#> : HandyJSON {\n\n", at: 0)
        content.append("\n\nrequired init() {}")
        content.append("\n\n}")
        classContent.append(content)
    }
    
}

